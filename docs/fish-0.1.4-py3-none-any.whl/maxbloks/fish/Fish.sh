#!/bin/sh

PYTHON=python3
THIS_DIR="$(readlink -f $(dirname $0))"
NAME="$(basename $0 .sh)"

#cd "$THIS_DIR/$NAME"
#$PYTHON main.py

python3 -m maxbloks.fish.main
