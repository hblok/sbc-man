from maxbloks.fish.fish_game import FishGame

if __name__ == "__main__":
    game = FishGame(width=800, height=600, title="Fish Feeding Frenzy")
    game.run()

    
