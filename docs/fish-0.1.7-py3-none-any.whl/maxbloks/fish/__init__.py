from maxbloks.fish.fish_game import FishGame

def start():
    game = FishGame(width=800, height=600, title="Fish Feeding Frenzy")
    game.run()
    
